var recordData = [
 {
  "length": 24804,
  "seq_id": "BOBONEKI_1_PP1",
  "regions": []
 }
];
var all_regions = {
 "order": []
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
