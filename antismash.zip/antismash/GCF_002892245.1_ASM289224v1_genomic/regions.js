var recordData = [
 {
  "length": 25112,
  "seq_id": "NDLFCIIA_1_PP1",
  "regions": []
 }
];
var all_regions = {
 "order": []
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
